// popup.js
document.getElementById('helloButton').addEventListener('click', function() {
    alert('Hello, World!');
  });
  