// ==UserScript==
// @name         时间提醒
// @namespace    http://tampermonkey.net/
// @version      2024-10-10
// @description  try to take over the world!
// @author       Chenpeng
// @match        http://*/*
// @match        https://*/*
// @icon         data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    console.log('Hello,this is a new diy_script!');

    function alertduan(){
        alert("辛苦一天了，时候不早了，去睡觉吧！");
    }

    //document.write(Date());
   // debugger;
    // 获取当前时间
    const timenow = new Date();
    const currentHour = timenow.getHours();
    //设置提醒冷却时间
    let coldtime=null;
    // 检查当前时间是否在晚上9点到早上2点之间
    if (currentHour >= 23 || currentHour < 2) {
        if(coldtime===null){
         alertduan();
            coldtime=setTimeout(()=>{
                coldtime=null;
            },5000);
        }
    }
})();